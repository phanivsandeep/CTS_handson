package com.cognizant.springlearn.exception;

public class EmployeeNotFoundException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public EmployeeNotFoundException(String string) {
		super(string);
	}
}
